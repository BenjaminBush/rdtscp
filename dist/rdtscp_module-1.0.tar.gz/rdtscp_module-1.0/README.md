This is a C extension for Python3 to call RDTSCP(). Tested on Python3.6, but should work for all Python 3.x versions.


Usage:

import rdtscp_module

print(rdtscp_module.rdtscp())
